<footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                        Copyright &copy; 2021 Huy ADMIN
                    </div>
                    <div class="col-sm-6 text-right">
                        LIÊN HỆ :
                        <a href="https://www.youtube.com/channel/UCAwNonyQevdBMD04cULCgBQ?view_as=subscriber"><i class="fa fa-youtube"></i></a>
                        <a href="https://www.youtube.com/channel/UCAwNonyQevdBMD04cULCgBQ?view_as=subscriber"><i class="fa fa-facebook"></i></a>
                        <a href="https://www.youtube.com/channel/UCAwNonyQevdBMD04cULCgBQ?view_as=subscriber"><i class="fa fa-instagram"></i></a>
                    </div>
                </div>
            </div>
        </footer>